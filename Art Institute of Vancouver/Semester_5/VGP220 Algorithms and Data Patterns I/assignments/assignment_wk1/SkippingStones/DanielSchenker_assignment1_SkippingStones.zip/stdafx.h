//-----------------------------
// File:		stdafx.h
// Created:		2012/07/06
// Copyright:	Daniel Schenker
//-----------------------------

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include <stdlib.h>
#include <time.h>