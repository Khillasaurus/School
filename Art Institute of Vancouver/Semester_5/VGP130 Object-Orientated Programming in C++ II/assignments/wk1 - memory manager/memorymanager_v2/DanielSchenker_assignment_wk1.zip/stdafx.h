//-----------------------------
// File:		stdafx.h
// Created:		2012/07/05
// Copyright:	Daniel Schenker
//-----------------------------

#pragma once

#define _CRT_SECURE_NO_WARNINGS

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>